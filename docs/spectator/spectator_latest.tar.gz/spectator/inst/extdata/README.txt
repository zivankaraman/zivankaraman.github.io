The file "luxembourg.geojson" was derived from the file downmaoded from 
https://download.data.public.lu/resources/limites-administratives-du-grand-duche-de-luxembourg/20180806-153458/communes4326.geojson
(last checked 2021-08-08).
The file "centralpark.geojson" was derived from the file downmaoded from 
https://data.cityofnewyork.us/Education/2017-2018-School-Zones/ghq4-ydq4
(last checked 2021-08-08).
